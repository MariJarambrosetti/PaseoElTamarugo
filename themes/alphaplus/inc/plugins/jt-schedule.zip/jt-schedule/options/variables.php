<?php

	if (!defined('jt_schedule_singlePage')) define('jt_schedule_singlePage', 'jt_schedule_singlePage'); 
	if (!defined('jt_schedule_page_style')) define('jt_schedule_page_style', 'jt_schedule_page_style'); 

	// Translations
	if (!defined('jt_schedule_shortInfoText')) define('jt_schedule_shortInfoText', 'jt_schedule_shortInfoText'); 
	if (!defined('jt_schedule_startsText')) define('jt_schedule_startsText', 'jt_schedule_startsText'); 
	if (!defined('jt_schedule_durationText')) define('jt_schedule_durationText', 'jt_schedule_durationText'); 
	if (!defined('jt_schedule_instructorText')) define('jt_schedule_instructorText', 'jt_schedule_instructorText'); 
	if (!defined('jt_schedule_classText')) define('jt_schedule_classText', 'jt_schedule_classText'); 
	if (!defined('jt_schedule_priceText')) define('jt_schedule_priceText', 'jt_schedule_priceText'); 
	if (!defined('jt_schedule_colorText')) define('jt_schedule_colorText', 'jt_schedule_colorText'); 
	if (!defined('jt_schedule_signupText')) define('jt_schedule_signupText', 'jt_schedule_signupText'); 
	if (!defined('jt_schedule_registrationFormText')) define('jt_schedule_registrationFormText', 'jt_schedule_registrationFormText'); 
	if (!defined('jt_schedule_customFormText')) define('jt_schedule_customFormText', 'jt_schedule_customFormText'); 

	if (!defined('jt_schedule_firstnameText')) define('jt_schedule_firstnameText', 'jt_schedule_firstnameText'); 
	if (!defined('jt_schedule_lastnameText')) define('jt_schedule_lastnameText', 'jt_schedule_lastnameText'); 
	if (!defined('jt_schedule_emailText')) define('jt_schedule_emailText', 'jt_schedule_emailText'); 
	if (!defined('jt_schedule_phoneText')) define('jt_schedule_phoneText', 'jt_schedule_phoneText'); 
	if (!defined('jt_schedule_dayText')) define('jt_schedule_dayText', 'jt_schedule_dayText'); 
	if (!defined('jt_schedule_submitText')) define('jt_schedule_submitText', 'jt_schedule_submitText'); 

	if (!defined('jt_schedule_videoText')) define('jt_schedule_videoText', 'jt_schedule_videoText'); 
	if (!defined('jt_schedule_videoEmbedText')) define('jt_schedule_videoEmbedText', 'jt_schedule_videoEmbedText'); 
	if (!defined('jt_schedule_galleryText')) define('jt_schedule_galleryText', 'jt_schedule_galleryText'); 
	if (!defined('jt_schedule_uploadText')) define('jt_schedule_uploadText', 'jt_schedule_uploadText'); 
	if (!defined('jt_schedule_basicInfoText')) define('jt_schedule_basicInfoText', 'jt_schedule_basicInfoText'); 
	if (!defined('jt_schedule_infoText')) define('jt_schedule_infoText', 'jt_schedule_infoText'); 
	if (!defined('jt_schedule_mediaText')) define('jt_schedule_mediaText', 'jt_schedule_mediaText'); 
	if (!defined('jt_schedule_settingsText')) define('jt_schedule_settingsText', 'jt_schedule_settingsText'); 

	if (!defined('jt_schedule_userRegisteredText')) define('jt_schedule_userRegisteredText', 'jt_schedule_userRegisteredText'); 
	if (!defined('jt_schedule_nameText')) define('jt_schedule_nameText', 'jt_schedule_nameText'); 
	if (!defined('jt_schedule_timeText')) define('jt_schedule_timeText', 'jt_schedule_timeText'); 

?>