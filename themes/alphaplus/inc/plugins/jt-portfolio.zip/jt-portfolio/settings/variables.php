<?php
	if (!defined('project_page')) define('project_page', 'project_page'); 
	if (!defined('project_page_style')) define('project_page_style', 'project_page_style'); 
	if (!defined('project_date_format')) define('project_date_format', 'project_date_format'); 

	if (!defined('project_client')) define('project_client', 'project_client'); 
	if (!defined('project_country')) define('project_country', 'project_country'); 
	if (!defined('project_budget')) define('project_budget', 'project_budget'); 
	if (!defined('project_date')) define('project_date', 'project_date'); 
	if (!defined('project_implementation_time')) define('project_implementation_time', 'project_implementation_time'); 
	if (!defined('project_website')) define('project_website', 'project_website'); 
	if (!defined('project_gallery')) define('project_gallery', 'project_gallery'); 
	if (!defined('project_video')) define('project_video', 'project_video'); 
?>