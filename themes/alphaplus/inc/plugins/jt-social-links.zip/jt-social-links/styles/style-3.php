<div class="uk-grid jsquare-social-links-3">
<?php
			
	if ( rtrim($behance) != NULL ) {
		echo __('<div class="uk-width-1-3 column behance-icon">');
			echo '<a class="behance-icon" href="' . esc_html( $behance ) . '"><i class="fa fa-behance"></i><span>Behance</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($dribbble) != NULL ) {
		echo __('<div class="uk-width-1-3 column dribbble-icon">');
			echo '<a class="dribbble-icon" href="' . esc_html( $dribbble ) . '"><i class="fa fa-dribbble"></i><span>Dribbble</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($facebook) != NULL ) {
		echo __('<div class="uk-width-1-3 column facebook-icon">');
			echo '<a class="facebook-icon" href="' . esc_html( $facebook ) . '"><i class="fa fa-facebook"></i><span>Facebook</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($flickr) != NULL ) {
		echo __('<div class="uk-width-1-3 column flickr-icon">');
			echo '<a class="flickr-icon" href="' . esc_html( $flickr ) . '"><i class="fa fa-flickr"></i><span>Flickr</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($foursquare) != NULL ) {
		echo __('<div class="uk-width-1-3 column foursquare-icon">');
			echo '<a class="foursquare-icon" href="' . esc_html( $foursquare ) . '"><i class="fa fa-foursquare"></i><span>Foursquare</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($github) != NULL ) {
		echo __('<div class="uk-width-1-3 column github-icon">');
			echo '<a class="github-icon" href="' . esc_html( $github ) . '"><i class="fa fa-github"></i><span>Github</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($gplus) != NULL ) {
		echo __('<div class="uk-width-1-3 column gplus-icon">');
			echo '<a class="gplus-icon" href="' . esc_html( $gplus ) . '"><i class="fa fa-google-plus"></i><span>Google+</span></a>';
		echo __('</div>');
	}

	if ( rtrim($instagram) != NULL ) {
		echo __('<div class="uk-width-1-3 column instagram-icon">');
			echo '<a class="instagram-icon" href="' . esc_html( $instagram ) . '"><i class="fa fa-instagram"></i><span>Instagram</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($linkedin) != NULL ) {
		echo __('<div class="uk-width-1-3 column linkedin-icon">');
			echo '<a class="linkedin-icon" href="' . esc_html( $linkedin ) . '"><i class="fa fa-linkedin"></i><span>LinkedIn</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($pinterest) != NULL ) {
		echo __('<div class="uk-width-1-3 column pinterest-icon">');
			echo '<a class="pinterest-icon" href="' . esc_html( $pinterest ) . '"><i class="fa fa-pinterest"></i><span>Pinterest</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($tumblr) != NULL ) {
		echo __('<div class="uk-width-1-3 column tumblr-icon">');
			echo '<a class="tumblr-icon" href="' . esc_html( $tumblr ) . '"><i class="fa fa-tumblr"></i><span>Tumblr</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($twitter) != NULL ) {
		echo __('<div class="uk-width-1-3 column twitter-icon">');
			echo '<a class="twitter-icon" href="' . esc_html( $twitter ) . '"><i class="fa fa-twitter"></i><span>Twitter</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($vimeo) != NULL ) {
		echo __('<div class="uk-width-1-3 column vimeo-icon">');
			echo '<a class="vimeo-icon" href="' . esc_html( $vimeo ) . '"><i class="fa fa-vimeo"></i><span>Vimeo</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($vine) != NULL ) {
		echo __('<div class="uk-width-1-3 column vine-icon">');
			echo '<a class="vine-icon" href="' . esc_html( $vine ) . '"><i class="fa fa-vine"></i><span>Vine</span></a>';
		echo __('</div>');
	}
		
	if ( rtrim($youtube) != NULL ) {
		echo __('<div class="uk-width-1-3 column youtube-icon">');
			echo '<a class="youtube-icon" href="' . esc_html( $youtube ) . '"><i class="fa fa-youtube-play"></i><span>YouTube</span></a>';
		echo __('</div>');
	}

?>
</div>